"""
Python port of llama-bench.cpp

This script replicates the benchmarking logic of llama-bench.cpp, using stubs for llama, ggml, and common functionality.
"""
import argparse
import sys
import time
import threading
import enum
import math
import statistics
import re
import json
import csv
import io
from typing import List, Tuple, Dict, Any, Optional
from itertools import product
import os

from openai import OpenAI


# Set OpenAI API base to local llama.cpp server (use a dummy key for local server)
openai_base_url="http://127.0.0.1:8007/v1"
openai_api_key="bench-local"

# Output format enum
class OutputFormat(enum.Enum):
    NONE = 'none'
    CSV = 'csv'
    JSON = 'json'
    MARKDOWN = 'md'
    # Removed JSONL and SQL

    @staticmethod
    def from_str(s: str):
        s = s.lower()
        for fmt in OutputFormat:
            if fmt.value == s:
                return fmt
        raise ValueError(f"Invalid output format: {s}")

# Utility functions

def get_time_ns() -> int:
    return int(time.time() * 1e9)

def join(values, delim: str) -> str:
    return delim.join(str(v) for v in values)

def avg(v: List[float]) -> float:
    return statistics.mean(v) if v else 0.0

def stdev(v: List[float]) -> float:
    return statistics.stdev(v) if len(v) > 1 else 0.0

def parse_int_range(s: str) -> List[int]:
    # first[-last[(+|*)step]]
    result = []
    range_regex = re.compile(r"^(\d+)(?:-(\d+)([+*])?(\d+)?)?(?:,|$)")
    search_start = 0
    while search_start < len(s):
        match = range_regex.match(s, search_start)
        if not match:
            raise ValueError("invalid range format")
        first = int(match.group(1))
        last = int(match.group(2)) if match.group(2) else first
        op = match.group(3) if match.group(3) else '+'
        step = int(match.group(4)) if match.group(4) else 1
        i = first
        while i <= last:
            result.append(i)
            prev_i = i
            if op == '+':
                i += step
            elif op == '*':
                i *= step
            else:
                raise ValueError("invalid range format")
            if i <= prev_i:
                raise ValueError("invalid range")
        search_start = match.end()
    return result

# Default parameters (partial, for demonstration)
def get_default_params() -> dict:
    return {
        'n_prompt': [512],
        'n_gen': [128],
        'n_depth': [0],
        'n_batch': [2048],
        'n_ubatch': [512],
        'reps': 5,
        'output_format': OutputFormat.MARKDOWN,
        'output_format_stderr': OutputFormat.NONE,
        'verbose': False,
        'progress': False,
        # Add more defaults as needed
    }

# Data structure for command line parameters
class CmdParams:
    def __init__(self, **kwargs):
        defaults = get_default_params()
        for k, v in defaults.items():
            # Always store as scalar, unless explicitly a list parameter
            if k in ['n_prompt', 'n_gen', 'n_batch', 'n_gpu_layers']:
                setattr(self, k, kwargs.get(k, v))
            else:
                # Unwrap single-item lists for scalar params
                val = kwargs.get(k, v)
                if isinstance(val, list) and len(val) == 1:
                    setattr(self, k, val[0])
                else:
                    setattr(self, k, val)

# Test result structure (partial, for demonstration)
class TestResult:
    def __init__(self, params: CmdParams):
        self.model_filename = ""
        self.n_prompt = params.n_prompt[0] if hasattr(params, 'n_prompt') and isinstance(params.n_prompt, list) else getattr(params, 'n_prompt', None)
        self.n_gen = params.n_gen[0] if hasattr(params, 'n_gen') and isinstance(params.n_gen, list) else getattr(params, 'n_gen', None)
        self.n_batch = params.n_batch[0] if hasattr(params, 'n_batch') and isinstance(params.n_batch, list) else getattr(params, 'n_batch', None)
        self.n_gpu_layers = getattr(params, 'n_gpu_layers', None)
        self.flash_attn = getattr(params, 'flash_attn', None)
        self.reps = getattr(params, 'reps', None)
        self.verbose = getattr(params, 'verbose', None)
        self.progress = getattr(params, 'progress', None)
        self.samples_ns: List[int] = []
        self.test_time = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

    def avg_ns(self) -> float:
        return avg(self.samples_ns)

    def stdev_ns(self) -> float:
        return stdev(self.samples_ns)

    def get_ts(self) -> List[float]:
        n_tokens = self.n_prompt + self.n_gen
        return [1e9 * n_tokens / t for t in self.samples_ns if t > 0]

    def avg_ts(self) -> float:
        ts = self.get_ts()
        return avg(ts)

    def stdev_ts(self) -> float:
        ts = self.get_ts()
        return stdev(ts)

    def as_dict(self) -> dict:
        return {
            "model": self.model_filename,
            "prompt": self.n_prompt,
            "gen": self.n_gen,
            "batch": self.n_batch,
            "n_gpu_layers": self.n_gpu_layers,
            "flash_attn": self.flash_attn,
            "reps": self.reps,
            "verbose": self.verbose,
            "progress": self.progress,
            "avg_ns": round(self.avg_ns()),
            "stdev_ns": round(self.stdev_ns()),
            "avg_t_s": round(self.avg_ts(), 2),
            "stdev_t_s": round(self.stdev_ts(), 2),
            "time": self.test_time
        }

# Output formatting (partial, only markdown for now)
def print_markdown_header(params: CmdParams):
    print("| Model | Prompt | Gen | Batch | n_gpu_layers | FlashAttn | Reps | Verbose | Progress | Avg ns | Stdev ns | Avg t/s | Stdev t/s | Time |")
    print("|-------|--------|-----|-------|-------------|-----------|------|---------|----------|--------|----------|---------|-----------|------|")

def print_markdown_result(result: TestResult):
    print(f"| {result.model_filename} | {result.n_prompt} | {result.n_gen} | {result.n_batch} | {result.n_gpu_layers} | {result.flash_attn} | {result.reps} | {result.verbose} | {result.progress} | {result.avg_ns():.0f} | {result.stdev_ns():.0f} | {result.avg_ts():.2f} | {result.stdev_ts():.2f} | {result.test_time} |")

def print_csv_header():
    print("model,prompt,gen,batch,n_gpu_layers,flash_attn,reps,verbose,progress,avg_ns,stdev_ns,avg_t_s,stdev_t_s,time")

def print_csv_result(result: TestResult):
    d = result.as_dict()
    print(f"{d['model']},{d['prompt']},{d['gen']},{d['batch']},{d['n_gpu_layers']},{d['flash_attn']},{d['reps']},{d['verbose']},{d['progress']},{d['avg_ns']},{d['stdev_ns']},{d['avg_t_s']},{d['stdev_t_s']},{d['time']}")

def print_json_result(result: TestResult):
    print(json.dumps(result.as_dict()))

def print_jsonl_result(result: TestResult):
    pass  # Removed JSONL output

def print_sql_result(result: TestResult):
    pass  # Removed SQL output

def print_none_result(result: TestResult):
    pass  # Do not print anything

# Stub: load a model - just returns the server's first models's name
def load_model(client):
    """
    For OpenAI-compatible llama.cpp server, query /models endpoint to get the default model name.
    """
    model_name = None
    try:
        model_0_name = client.models.list().data[0].id
    except Exception as e:
        print(f"[llama-bench] Could not list models: {e}")
    return model_0_name

# Stub: run inference (to be implemented)
def run_inference(client, model, n_prompt, n_gen, n_batch):
    """
    Run inference using the local llama.cpp OpenAI-compatible server.
    """
    test_prompt_text = "Test "
    # Repeat test_prompt_text to reach exactly n_prompt characters
    repeats = n_prompt // len(test_prompt_text)
    remainder = n_prompt % len(test_prompt_text)
    prompt = (test_prompt_text * repeats) + test_prompt_text[:remainder]
    try:
        response = client.completions.create(
            model=model,
            prompt=prompt,
            max_tokens=n_gen,
            # n=n_batch,
            # temperature=0.0
        )       
    except Exception as e:
        print(f"[llama-bench] Inference error: {e}")

def run_benchmark(client, params: CmdParams) -> TestResult:
    result = TestResult(params)
    # if result.verbose:
    ### Print system and backend info at the start of the first test
    # ToDo!!!!!
    
    # Load model once per test
    result.model_filename = load_model(client)
    for _ in range(result.reps):
        start = get_time_ns()
        run_inference(
            client, 
            result.model_filename, 
            result.n_prompt, 
            result.n_gen, 
            result.n_batch)
        end = get_time_ns()
        result.samples_ns.append(end - start)
    return result

# Helper to generate all combinations of parameter lists
def expand_params(params: CmdParams) -> List[CmdParams]:
    # Only expand over lists, keep scalars as is
    param_lists = {}
    for k, v in params.__dict__.items():
        if isinstance(v, list) and len(v) > 1:
            param_lists[k] = v
        elif isinstance(v, list):
            param_lists[k] = v
        else:
            param_lists[k] = [v]
    keys = list(param_lists.keys())
    value_lists = [param_lists[k] for k in keys]
    combos = list(product(*value_lists))
    expanded = []
    for combo in combos:
        combo_dict = {k: [v] if isinstance(param_lists[k], list) else v for k, v in zip(keys, combo)}
        expanded.append(CmdParams(**combo_dict))
    return expanded

# For now, just a CLI skeleton

def main():

    # Print banner
    print("llama-bench.py: Python port of llama-bench.cpp")

    # get openAI API
    try:
        client = OpenAI(base_url=openai_base_url, api_key=openai_api_key)
    except Exception as e:
        print(f"[llama-bench] Could not load openAI API {e}")


    # Parse command line arguments
    parser = argparse.ArgumentParser(description="Python port of llama-bench.cpp benchmark tool.")

    # Options
    options = parser.add_argument_group('options:')
    # Remove explicit -h/--help, argparse adds it by default
    options.add_argument('--progress', action='store_true', help='Print test progress indicators')
    options.add_argument('-r', '--repetitions', type=int, default=1, help='Number of times to repeat each test (default: 5)') # 5
    options.add_argument('-o', '--output', type=str, default='md', help='Output format printed to stdout (csv, json, jsonl, md, sql)')
    options.add_argument('-v', '--verbose', action='store_true', help='Verbose output')

    # Test parameters
    test_params = parser.add_argument_group('test parameters:')
    # Removed -m/--model
    test_params.add_argument('-p', '--n-prompt', type=int, default=512, help='Prompt size')
    test_params.add_argument('-n', '--n-gen', type=int, default=128, help='Generation size')
    test_params.add_argument('-pg', '--prompt-gen-defaults', nargs='*', type=int, help='Run for both prompt and gen with their default values, or optionally provide prompt and gen values')
    test_params.add_argument('-b', '--batch-size', type=int, default=2048, help='Batch size')
    test_params.add_argument('-ngl', '--n-gpu-layers', type=int, default=99, help='Number of GPU layers')
    test_params.add_argument('-fa', '--flash-attn', type=int, choices=[0,1], default=0, help='Flash attention (0 or 1)')

    args = parser.parse_args()

    # Handle -pg: run for both prompt and gen with their default values, or optionally provided values
    n_prompt = [args.n_prompt]
    n_gen = [args.n_gen]
    if args.prompt_gen_defaults is not None:
        if len(args.prompt_gen_defaults) == 2:
            n_prompt = [args.prompt_gen_defaults[0]]
            n_gen = [args.prompt_gen_defaults[1]]
        else:
            n_prompt = [512]
            n_gen = [128]

    # Map CLI args to CmdParams
    params = CmdParams(
        n_prompt=n_prompt,
        n_gen=n_gen,
        n_batch=[args.batch_size],
        n_gpu_layers=[args.n_gpu_layers],
        flash_attn=[bool(args.flash_attn)],
        reps=args.repetitions,
        output_format=OutputFormat.from_str(args.output),
        verbose=args.verbose,
        progress=args.progress,
    )

    print(f"[INFO] Prompt size: {params.n_prompt}, Generation size: {params.n_gen}, Batch: {params.n_batch}, Repetitions: {params.reps}")
    print(f"[INFO] Output format: {params.output_format}, Verbose: {params.verbose}, Progress: {params.progress}")
    # Only print n_gpu_layers and flash_attn if present
    if hasattr(params, 'n_gpu_layers'):
        print(f"[INFO] n_gpu_layers: {params.n_gpu_layers}")
    if hasattr(params, 'flash_attn'):
        print(f"[INFO] flash_attn: {params.flash_attn}")

    # Expand parameter grid for batch/multi-result output
    param_grid = expand_params(params)
    results = [run_benchmark(client, p) for p in param_grid]

    if params.output_format == OutputFormat.MARKDOWN:
        print_markdown_header(params)
        for result in results:
            print_markdown_result(result)
    elif params.output_format == OutputFormat.CSV:
        print_csv_header()
        for result in results:
            print_csv_result(result)
    elif params.output_format == OutputFormat.JSON:
        print(json.dumps([r.as_dict() for r in results]))
    elif params.output_format == OutputFormat.NONE:
        pass
    else:
        print("[ERROR] Unknown output format.", file=sys.stderr)

if __name__ == "__main__":
    main()
