from __future__ import annotations

import argparse
import json
import sys
import time
import traceback
import requests
from statistics import mean, stdev

# VSCode AI Toolkit Benchmarking Tool
# This benchmark-tool is based very loosely on llama.cpp's server/bench.py
# (c) 2025, Andreas Kunar, andreask@msn.com

# server-request helper-Function for the benchmark
# it uses the generic open-ai API 'v1/chat/completions' endpoint, WITHOUT A KEY!
def server_benchmark_request(args,prompt,n_gen):
    # Send a request to the server to benchmark the model
    url = f"http://{args.host}:{args.port}/v1/chat/completions"
    header = { "Content-Type": "application/json" }
    data = {
        "model": args.model,
        "messages": [ { 
            "role": "user", 
            "content": prompt 
        } ], 
        "max_tokens": n_gen,
        "temperature": 1
    }
    # Convert the data to JSON format
    data = json.dumps(data)
    # Send + time the request
    start_time = time.time()
    response = requests.post(url, data=data, headers=header)
    time_taken = time.time() - start_time
    if response.status_code != 200:
        raise RuntimeError(f"bench: server request failed with status code {response.status_code}: {response.text}")
    # Parse the JSON response
    response_data = response.json()
    if 'error' in response_data:
        raise RuntimeError(f"bench: server request failed with error: {response_data['error']}")
    # Process response_data - ###ToDo###
    return time_taken


# Run the benchmark
def run_benchmark(args, results):

    print("Starting benchmark server-calls .", end="", flush=True)
    
    # we can't measure the time for pp, so we use a fixed prompt and measure the time for a single token generation overhead
    prompt = "Write a long story."
    time_warmup=server_benchmark_request(args, prompt, 1) # we do a warmup-run to ignore the overhead of a first request
    time_overhead=server_benchmark_request(args, prompt, 1)
    
    # we do args.repetitions iterations of the benchmark
    tg_timings = []
    for iteration in range(args.repetitions):
        print(".", end="", flush=True)
        time_run=server_benchmark_request(args, prompt, args.n_gen+1)  # +1 to account for measured oveverhead token
        # measures time taken for request
        tg_timings.append(1000/((time_run - time_overhead) / args.n_gen))  # convert to tokens per second

    # calculate the average of the timings, prompt/predicted_per_token_ms -> tokens_per_second
    results['tg_avg'] = mean(tg_timings)
    results['tg_avg_stdev'] = stdev(tg_timings)
    print(".", flush=True)

###
### print the results in .md format
###
def print_results(args, results):
    print("")
    print(f"| model                     | test |          t/s |")
    print(f"|---------------------------|------|--------------|")
    print(f"| {args.model} | tg{args.n_gen} | {results['tg_avg']:.2f} ± {results['tg_avg_stdev']:.2f} |")
    print("\n")

###
### main
###

def main(args_in: list[str] | None = None) -> None:

    print("\nVSCode AI Toolkit Benchmarking Tool V1.0\n")

    parser = argparse.ArgumentParser(description="Local AI-server benchmark using http:")

    # parameterd for running the local server
    parser.add_argument("--host", type=str, help="Server listen host", default="localhost")
    parser.add_argument("--port", type=int, help="Server listen port", default="5272")
    parser.add_argument('-m', "--model", type=str, help="Model name", default="Phi-4-mini-reasoning-3.8b-qnn")

    # parameters for the benchmark
    parser.add_argument("-r", "--repetitions", type=int, help="Number of times to repeat each test", default=5)
    parser.add_argument("-n", "--n-gen", type=int, help="Tokens to generate", default=128)

    args = parser.parse_args(args_in)

    # Benchmarking and print the results
    try:
        results = {}
        run_benchmark(args, results)
        print_results(args, results)
    except Exception:
        print("bench: error :")
        traceback.print_exc(file=sys.stdout)


if __name__ == '__main__':
    main()
