# bench-py

This project is a Python port of a small functional subset of llama-bench.cpp from llama.cpp, but it uses the llama.cpp server API as the source for benchmarking.

The benchmarking logic is implemented in `bench.py`. Command-line arguments are handled using `argparse`.

## How to run

1. Ensure you have Python 3.8+ and the llama.cpp llama-server installed.
2. Run the main benchmark script:

```text
python bench.py [options]
```

### Server-options

```text
  -h, --help                show this help message and exit
  --server-path <s>         Path to the llama.cpp server binary
  --host <s>                Server listen host
  --port <n>                Server listen port
  -m, --model MODEL         Model filename (type .gguf)
  -ngl, --n-gpu-layers <n>  layers to the GPU for computation
  -t, --threads <n>         Number of threads for the server
  --ctx-size <n>            Set the size of the prompt context
  --batch-size <n>          Set the batch size for prompt processing
  --ubatch-size <n>         physical maximum batch size
```

### Benchmark-options

```text
  -r, --repetitions <n>     Repeat each test this many times to average the random prompts
  -p, --n-prompt <n>        Prompt-length to benchmark
  -n, --n-gen <n>           Tokens to generate for the benchmark
```
