# bench-py

This project is a Python port of a small functional subset of llama-bench.cpp from llama.cpp, but it uses an openAI API compatible backend server as the source for benchmarking.

The main benchmarking logic is implemented in `llama_bench.py`. Command-line arguments are handled using `argparse`.

## How to run

1. Ensure you have Python 3.8+ and the openAI API installed.
2. Start the inference-server (e.g. llama.cpp's llama-server) with the model you want to benchmark. 
3. Run the main benchmark script:

```sh
python llama_bench.py [options]
```

### Options supported by this Project

  -h, --help - show help message and exit
  -r, --repetitions <n> - number of times to repeat each test (default: 5)
  -o, --output <csv|json|md> - output format printed to stdout (default: md)
  -v, --verbose - verbose output
  --progress - print test progress indicators

#### NOT Supported by this Project

- No --numa - no support for NUMA specifics settings
- No --prio - no support process/thread priority setting
- No --delay - no support for delays between each test
- No jsonl,sql output formats

## Test-Parameters/Functionality Supported by this Project

- No suppoert for -m/--model - this is taken from the local server's model-name

ToDo: - add what is supported!
