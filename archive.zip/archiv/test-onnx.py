import onnx
from onnx import mapping

def load_print_onnx_model(model_path,fn):
    print(f"ONNX model: {fn}")
    model = onnx.load(model_path+fn+".onnx")
    for init in model.graph.initializer:
        dtype = mapping.TENSOR_TYPE_TO_NP_TYPE[init.data_type]
        print(f"{init.name}: {dtype}")
    '''
    for node in model.graph.node:
        print(node)
    print("")
    '''

onnx_model_path="C:/Users/andre/.foundry/cache/models/Microsoft/Phi-4-mini-reasoning-qnn-npu/qnn-phi4-mini-reasoning-onnx/"
print("ONNX model path: " + onnx_model_path)

load_print_onnx_model(onnx_model_path,"phi_4_mini_ctx.onnx_ctx")
load_print_onnx_model(onnx_model_path,"phi_4_mini_embeddings.all.quant")
load_print_onnx_model(onnx_model_path,"phi_4_mini_iter.onnx_ctx")
load_print_onnx_model(onnx_model_path,"phi_4_mini_lm_head.all.quant")
