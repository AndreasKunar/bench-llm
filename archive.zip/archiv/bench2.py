import os
import time
import random
import openai

# ======================= PARAMETERS =======================

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY") or "sk-..."   # Set your API key here or via env variable
OPENAI_API_BASE = os.getenv("OPENAI_API_BASE") or None     # Set if using a custom endpoint

MODEL_NAME = "gpt-3.5-turbo"  # Or whatever model is supported by your endpoint
VOCABULARY = [  # A simple, sample vocab. Replace with real model tokens if needed
    "the", "and", "to", "a", "of", "in", "is", "it", "that", "for",
    "you", "with", "on", "as", "are", "this", "or", "be", "by", "at",
    "I", "have", "not", "was", "but", "from", "they", "he", "she", "an",
    "his", "her", "we", "do", "which", "their", "all", "my", "has", "if"
]
NUM_PROMPT_TOKENS = 64     # Number of random tokens in each prompt (prompt-processing test)
NUM_GEN_TOKENS = 32        # Number of tokens to generate (generation test)
NUM_RUNS = 5               # Number of runs to average (excluding warm-up)
SEED = 42                  # For reproducibility

# ======================= INIT =======================

random.seed(SEED)
if OPENAI_API_BASE:
    openai.api_base = OPENAI_API_BASE
openai.api_key = OPENAI_API_KEY

def generate_random_prompt(num_tokens):
    return " ".join(random.choices(VOCABULARY, k=num_tokens))

def measure_prompt_processing(model, num_tokens, runs):
    print(f"\nMeasuring prompt-processing ({num_tokens} tokens)...")
    timings = []
    for run in range(runs + 1):
        prompt = generate_random_prompt(num_tokens)
        messages = [{"role": "user", "content": prompt}]
        start = time.time()
        # Set max_tokens=1 to only process prompt, not generate much text
        _ = openai.ChatCompletion.create(
            model=model,
            messages=messages,
            max_tokens=1,
            temperature=0,
        )
        end = time.time()
        if run == 0:
            print("  Warm-up run finished.")
            continue
        timings.append(end - start)
        print(f"  Run {run}: {timings[-1]:.3f}s")
    avg_time = sum(timings) / len(timings)
    token_per_sec = num_tokens / avg_time
    print(f"  Average: {token_per_sec:.2f} prompt tokens/s\n")
    return token_per_sec

def measure_token_generation(model, prompt_length, gen_tokens, runs):
    print(f"\nMeasuring token-generation ({gen_tokens} tokens after prompt of {prompt_length})...")
    timings = []
    for run in range(runs + 1):
        prompt = generate_random_prompt(prompt_length)
        messages = [{"role": "user", "content": prompt}]
        start = time.time()
        _ = openai.ChatCompletion.create(
            model=model,
            messages=messages,
            max_tokens=gen_tokens,
            temperature=0,
        )
        end = time.time()
        if run == 0:
            print("  Warm-up run finished.")
            continue
        timings.append(end - start)
        print(f"  Run {run}: {timings[-1]:.3f}s")
    avg_time = sum(timings) / len(timings)
    token_per_sec = gen_tokens / avg_time
    print(f"  Average: {token_per_sec:.2f} generation tokens/s\n")
    return token_per_sec

# ======================= MAIN =======================

if __name__ == "__main__":
    print("=== AI API Benchmark Tool ===")
    print(f"Model: {MODEL_NAME}, API Base: {OPENAI_API_BASE or 'Default'}")
    # Prompt processing (input throughput)
    measure_prompt_processing(MODEL_NAME, NUM_PROMPT_TOKENS, NUM_RUNS)
    # Token generation (output throughput)
    measure_token_generation(MODEL_NAME, NUM_PROMPT_TOKENS, NUM_GEN_TOKENS, NUM_RUNS)