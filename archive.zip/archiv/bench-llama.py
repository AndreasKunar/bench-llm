from __future__ import annotations

import argparse
import json
import os
import re
import signal
import socket
import subprocess
import sys
import threading
import time
import traceback
from contextlib import closing
from datetime import datetime
import requests
from statistics import mean, stdev
import random 

###
### Aux functions for managing the local llama.cpp server
###
def start_server(args):
    # Start the server in the background and wait for it to be ready
    server_process = start_server_background(args)

    attempts = 0
    max_attempts = 600
    print(f"bench: waiting for server to start on {args.host}:{args.port} ...")
    
    while not is_server_listening(args.host, args.port):
        attempts += 1
        if attempts > max_attempts:
            assert False, "server not started"
        print(f"bench:     waiting for server to start ...")
        time.sleep(0.5)

    attempts = 0
    while not is_server_ready(args.host, args.port):
        attempts += 1
        if attempts > max_attempts:
            assert False, "server not ready"
        print(f"bench:     waiting for server to be ready ...")
        time.sleep(0.5)

    print("bench: server started and ready.")
    return server_process


def start_server_background(args):
    # Start the server in the background
    server_path = args.server_path
    if not os.path.exists(server_path):
        raise FileNotFoundError(f"bench: server binary not found at {server_path}")
    elif not os.path.isfile(server_path):
        raise FileNotFoundError(f"bench: server binary is not a file: {server_path}")
    server_args = [
        '--host', args.host,
        '--port', args.port,
    ]
    server_args.extend(['-m', args.model])
    server_args.extend(['--n-gpu-layers', args.n_gpu_layers])
    server_args.extend(['--ctx-size', args.ctx_size])
    server_args.extend(['--batch-size', args.batch_size])
    server_args.extend(['--ubatch-size', args.ubatch_size])
    server_args.extend(['--n-predict', args.n_prompt + args.n_gen +10])
    server_args.extend(['--defrag-thold', "0.1"])
    server_args.append('--cont-batching')
    server_args.append('--metrics')
    server_args.append('--flash-attn')
    
    args = [str(arg) for arg in [server_path, *server_args]]
    print(f"bench: starting server with: {' '.join(args)}")
    pkwargs = {
        'stdout': subprocess.PIPE,
        'stderr': subprocess.PIPE
    }
    server_process = subprocess.Popen(
        args,
        **pkwargs)  # pyright: ignore[reportArgumentType, reportCallIssue]

    def server_log(in_stream, out_stream):
        for line in iter(in_stream.readline, b''):
            print(line.decode('utf-8'), end='', file=out_stream)

    thread_stdout = threading.Thread(target=server_log, args=(server_process.stdout, sys.stdout))
    thread_stdout.start()
    thread_stderr = threading.Thread(target=server_log, args=(server_process.stderr, sys.stderr))
    thread_stderr.start()

    return server_process


def is_server_listening(server_fqdn, server_port):
    # Check if the server is listening on the specified host and port
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as sock:
        result = sock.connect_ex((server_fqdn, server_port))
        _is_server_listening = result == 0
        if _is_server_listening:
            print(f"server is listening on {server_fqdn}:{server_port}...")
        return _is_server_listening


def is_server_ready(server_fqdn, server_port):
    # Check if the server is ready by sending a health check request
    url = f"http://{server_fqdn}:{server_port}/health"
    response = requests.get(url)
    return response.status_code == 200


def stop_server(server_process, args):
    # Stop the server
    try:
        print(f"bench: shutting down server pid={server_process.pid} ...")
        if os.name == 'nt':
            interrupt = signal.CTRL_C_EVENT
        else:
            interrupt = signal.SIGINT
        server_process.send_signal(interrupt)
        server_process.wait(0.5)

    except subprocess.TimeoutExpired:
        print(f"server still alive after 500ms, force-killing pid={server_process.pid} ...")
        server_process.kill()  # SIGKILL
        server_process.wait()

    while is_server_listening(args.host, args.port):
        time.sleep(0.1)

###
### Helper-Functions for the benchmark
###
def model_get_token_cardinality(args):
    # Get the token cardinality from the model metadata
    # For now, we just return a dummy value
    return 256

def generate_prompt(args, token_cardinality):
    # Generate a prompt for the benchmark consisting of tokens
    # For now, we just return a dummy prompt
    # In a real scenario, this would be replaced with actual prompt generation logic
    prompt = []
    for i in range(args.n_prompt):
        # append randomly-generated integers to mprompt with a maximum value of token_cardinality
       prompt.append(random.randint(0, token_cardinality - 1))

    return prompt


def server_benchmark_request(args,prompt):
    # Send a request to the server to benchmark the model
    '''
    use a template similar to:
      curl --request POST \
        --url http://localhost:8007/completion \
        --header "Content-Type: application/json" \
        --data '{"prompt": [12, 34, 56], "n_predict": 16, \
            "response_fields": ["tokens_predicted", "tokens_evaluated", "timings/prompt_per_token_ms", "timings/predicted_per_token_ms"]}'
    '''
    url = f"http://{args.host}:{args.port}/completion"
    header = { "Content-Type": "application/json" }
    data = {
        "prompt": prompt,
        "n_predict": args.n_gen,
        "response_fields": ["tokens_predicted", "tokens_evaluated", "timings/prompt_per_token_ms", "timings/predicted_per_token_ms"]
    }
    # Convert the data to JSON format
    data = json.dumps(data)
    # Send the request
    response = requests.post(url, data=data, headers=header)
    if response.status_code != 200:
        raise RuntimeError(f"bench: server request failed with status code {response.status_code}: {response.text}")
    # Parse the JSON response
    response_data = response.json()
    if 'error' in response_data:
        raise RuntimeError(f"bench: server request failed with error: {response_data['error']}")
    # Process response_data - ###ToDo###
    return response_data
    


###
### Run the benchmark
###
def run_benchmark(args, results):

    # query the model info for tokenizer
    token_cardinality=model_get_token_cardinality(args)

    # we do args.repetitions iterations of the benchmark
    pp_timings = []
    tg_timings = []
    for iteration in range(args.repetitions):
        result=server_benchmark_request(args,generate_prompt(args, token_cardinality))
        # measures: "tokens_predicted", "tokens_evaluated", "timings/prompt_per_token_ms", "timings/predicted_per_token_ms"
        pp_timings.append(1000/result['timings/prompt_per_token_ms'])
        tg_timings.append(1000/result['timings/predicted_per_token_ms'])
    
    # calculate the average of the timings, prompt/predicted_per_token_ms -> tokens_per_second
    results['pp_avg'] = mean(pp_timings)
    results['pp_avg_stdev'] = stdev(pp_timings)
    results['tg_avg'] = mean(tg_timings)
    results['tg_avg_stdev'] = stdev(tg_timings)

###
### print the results in .md format
###
def print_results(args, results):
    print("\n")
    print(f"| model                     | threads | fa | test |          t/s |")
    print(f"|---------------------------|---------|----|------|--------------|")
    print(f"| {os.path.basename(args.model)} | {args.threads} |  1 | pp{args.n_prompt} | {results['pp_avg']:.2f}  ± {results['pp_avg_stdev']:.2f} |")
    print(f"| {os.path.basename(args.model)} | {args.threads} |  1 | tg{args.n_gen} | {results['tg_avg']:.2f} ± {results['tg_avg_stdev']:.2f} |")
    print("\n")

###
### main
###

def main(args_in: list[str] | None = None) -> None:

    print("\nLocal AI-server benchmark based on llama.cpp's server/bench.py V1.0\n\n")

    parser = argparse.ArgumentParser(description="Local AI-server benchmark using http:")

    # parameterd for running the local server
    parser.add_argument("--server-path", type=str, help="Path to the llama.cpp server binary", default='../llama.cpp/build/bin/llama-server')
    parser.add_argument("--host", type=str, help="Server listen host", default="127.0.0.1")
    parser.add_argument("--port", type=int, help="Server listen port", default="8007")
    parser.add_argument('-m', "--model", type=str, help="Model filename (type .gguf)", default="../models.llama.cpp/Llama/llama-2-7b-chat-Q4_0.gguf")
    parser.add_argument("-ngl", "--n-gpu-layers", type=int, help="layers to the GPU for computation", default=99)
    parser.add_argument( "-t", "--threads", type=int, help="Number of threads for the server", default=10)
    parser.add_argument("--ctx-size", type=int, help="Set the size of the prompt context", default=4096)
    parser.add_argument("--batch-size", type=int, help="Set the batch size for prompt processing", default=2048)
    parser.add_argument("--ubatch-size", type=int, help="physical maximum batch size", default=512)

    # parameters for the benchmark
    parser.add_argument("-r", "--repetitions", type=int, help="Number of times to repeat each test", default=5)
    parser.add_argument("-p", "--n-prompt", type=int, help="Prompt-length to test", default=512)
    parser.add_argument("-n", "--n-gen", type=int, help="Tokens to generate", default=128)

    args = parser.parse_args(args_in)

    # Start the server and performance scenario
    try:
        server_process = start_server(args)
    except Exception:
        print("bench: server start error :")
        traceback.print_exc(file=sys.stdout)
        sys.exit(1)

    # Benchmarking and print the results
    try:
        results = {}
        run_benchmark(args, results)
        print_results(args,results)
    except Exception:
        print("bench: error :")
        traceback.print_exc(file=sys.stdout)

    ## Stop server before exiting
    stop_server (server_process, args)


if __name__ == '__main__':
    main()
