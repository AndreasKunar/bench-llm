import openai
from foundry_local import FoundryLocalManager

# By using an alias, the most suitable model will be downloaded 
# to your end-user's device.
alias = "Phi-4-mini-reasoning-qnn-npu"

# Create a FoundryLocalManager instance. This will start the Foundry.
manager = FoundryLocalManager()

# Download and load a model
model_info = manager.download_model(alias)
model_info = manager.load_model(alias)

# The remaining code us es the OpenAI Python SDK to interact with the local model.

# Configure the client to use the local Foundry service
client = openai.OpenAI(
    base_url=manager.endpoint,
    api_key=manager.api_key  # API key is not required for local usage
)

# Set the model to use and generate a streaming response
result = client.chat.completions.create(
    model=manager.get_model_info(alias).id,
    messages=[{"role": "user", "content": "Why is the sky blue?"}]
)

# Print the streaming response
print(result)

# Unload a model
manager.unload_model(alias)
