from __future__ import annotations

import argparse
import json
import sys
import time
import traceback
import requests
from statistics import mean, stdev
import openai
from foundry_local import FoundryLocalManager

# Microsoft Foundry Local Benchmarking Tool
# This benchmark-tool is based very loosely on llama.cpp's server/bench.py
# (c) 2025, Andreas Kunar, andreask@msn.com

# server-request helper-Function for the benchmark
def server_benchmark_request(client, model, prompt, n_gen):
    # Send a request to the server to benchmark the model
    # + time the request
    start_time = time.time()
    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=n_gen,
        max_completion_tokens=n_gen,
        temperature=1
    )
    time_taken = time.time() - start_time
    return time_taken


# Run the benchmark
def run_benchmark(client, model, n_gen, repetitions, results):

    print("Starting benchmark server-calls .", end="", flush=True)
    
    # we can't measure the time for pp, so we use a fixed prompt and measure the time for a single token generation overhead
    prompt = "Write a long story."
    # we do a warmup-run to ignore the overhead of a first request
    time_warmup=server_benchmark_request(client, model, prompt, 100) 
    print(".", end="", flush=True)
    # then we measure the overhead for a few token generations
    n_overhead=60  # number of tokens to generate for the overhead measurement
    time_overhead=server_benchmark_request(client, model, prompt, n_overhead)
    
    # we do args.repetitions iterations of the benchmark
    tg_timings = []
    for iteration in range(repetitions):
        print(".", end="", flush=True)
        time_run=server_benchmark_request(client, model, prompt, n_gen + n_overhead)  # +1 to account for measured oveverhead token
        # measures time taken for request
        tg_timings.append(1/((time_run - time_overhead) / n_gen))  # convert to tokens per second

    # calculate the average of the timings, prompt/predicted_per_token_ms -> tokens_per_second
    results['tg_avg'] = mean(tg_timings)
    results['tg_avg_stdev'] = stdev(tg_timings)
    print(".", flush=True)


### print the results in .md format
def print_results(model, n_gen, results):
    print("")
    print(f"| model                        |  test |          t/s |")
    print(f"|------------------------------|-------|--------------|")
    print(f"| {model} | tg{n_gen} | {results['tg_avg']:.2f} ± {results['tg_avg_stdev']:.2f} |")
    print("\n")

###
### main
###
def main(args_in: list[str] | None = None) -> None:

    print("\nMicrosoft Foundry Local Benchmarking Tool V1.0\n")

    parser = argparse.ArgumentParser(description="Local AI-server benchmark using http:")

    # parameterd for running the local server
    parser.add_argument('-m', "--model", type=str, help="Model name", default="Phi-4-mini-reasoning-qnn-npu")

    # parameters for the benchmark
    parser.add_argument("-r", "--repetitions", type=int, help="Number of times to repeat each test", default=5)
    parser.add_argument("-n", "--n-gen", type=int, help="Tokens to generate", default=128)

    args = parser.parse_args(args_in)
    
    # Create an instance of the FoundryLocalManager anddownload the model
    print("bench: initializing Local Foundry and loading the model.", flush=True)
    try:
        manager = FoundryLocalManager(alias_or_model_id=args.model, bootstrap=True)
        model_info = manager.download_model(args.model)
        model_info = manager.load_model(args.model)
    except Exception:
        print("bench: error initializing Local Foundry:")
        traceback.print_exc(file=sys.stdout)
        sys.exit(1)
    print("    ... done.", flush=True)

    # Create an OpenAI client using the FoundryLocalManager
    client = openai.OpenAI(
        base_url=manager.endpoint,
        api_key=manager.api_key  # API key is not required for local usage
    )
    
    # Benchmarking and print the results
    try:
        results = {}
        run_benchmark(client, manager.get_model_info(args.model).id, args.n_gen, args.repetitions, results)
        print_results(manager.get_model_info(args.model).id, args.n_gen, results)
    except Exception:
        print("bench: error :")
        traceback.print_exc(file=sys.stdout)

    # cleanup
    manager.unload_model(args.model)


if __name__ == '__main__':
    main()
